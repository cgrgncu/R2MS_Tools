%**************************************************************************
%   Name: Main.m v20211125a
%   Copyright:  
%   Author: HsiupoYeh 
%   Version: v20211125a
%   Description: R2MS_CsvtoUrf_MultipleTx_Chu2019���I�s�d�ҡC
%   �ݨD: R2MS_CsvtoUrf_MultipleTx_Chu2019.m
%         yeh_ini2struct_ansi.m
%**************************************************************************
clear;clc;close all

% �D�{���Ѽ�INI�ɮצ�m
main_ini_full_file_name='Input_ini\R2MS_CsvtoUrf_MultipleTx.ini';
% �I�s
R2MS_CsvtoUrf_MultipleTx_Chu2019(main_ini_full_file_name);
