%**************************************************************************
%   Name: R2MS_Lite_v297csv_to_v297Ecsv.m v20240408a
%   Copyright:  
%   Author: HsiupoYeh 
%   Version: v20240408a
%   Description: �����uR2MS_Lite�v�b�s��o�e�T��(�P�ɦh�յo�g�T��)�ɡA�̷�
%                ����n�骩�����P�A�|�������CSV��ơAERT_ver2_9_7�n����x�s��
%                ��͸�ƺ٬��uv297rawcsv�v�C�t���n��N�i�@�B���ɬ��uv297csv�v
%               �A�O�����Y��CSV�榡(�R�W��:�u*.v297.csv�v)�C
%                ���F�ۮe�L�h���uR2MS_CsvtoUrf_MultipleTx_Chu2019_v20211126a�v
%                �ݭn��uv297csv�v���ɬ��uv297Ecsv�v(�R�W��:�u*.v297E.csv�v)
%                ��X�ɮױj���x�s�bOutput��Ƨ����C
%                �������u�䴩�з�65���q���Ϊ��`�Ω�q�Ҧ��C
%   �ϥΤ�k(MATLAB):
%           R2MS_Lite_v297csv_to_v297Ecsv('Input\S001202403292001.v297.csv','Output','S001202403292001')
%   �ϥΤ�k(DOS):
%           R2MS_Lite_v297csv_to_v297Ecsv "Input\S001202403292001.v297.csv" "Output" "S001202403292001"
%**************************************************************************
function R2MS_Lite_v297csv_to_v297Ecsv(Input_R2MS_Lite_v297csv_filename,Output_R2MS_Lite_v297Ecsv_folder,Output_R2MS_Lite_v297Ecsv_filename)
%     clear;clc;close all
%     Input_R2MS_Lite_v297csv_filename='Input\S001202403292001.v297.csv';
%     Output_R2MS_Lite_v297Ecsv_folder='Output';
%     Output_R2MS_Lite_v297Ecsv_filename='S001202403292001';    
    %----------------------------------------------------------------------
    % ���o�B��}�l�ɶ�
    program_start_time=now;
    %----------------------------------------------------------------------
    % ������T
    Version_str='v20240408a';
    %--
    % ���ܵe��
    disp('************************************************************')
    disp(['* R2MS_Lite_v297csv_to_v297Ecsv ',Version_str])
    disp('* Author: HsiupoYeh')
    disp(['* Version: ',Version_str])
    %----------------------------------------------------------------------
    % �ϥδ���
    if ~exist('Input_R2MS_Lite_v297csv_filename','var')
        disp('* MATLAB Usage:')
        disp('* R2MS_Lite_v297csv_to_v297Ecsv(''Input\S001202403292001.v297.csv'',''Output'',''S001202403292001'')')
		disp('* DOS Usage:')
        disp('* R2MS_Lite_v297csv_to_v297Ecsv "Input\S001202403292001.v297.csv" "Output" "S001202403292001"')
        disp('************************************************************')
        return
    end
    disp('************************************************************') 
    %----------------------------------------------------------------------
    disp(['�{���}�l�B��...�ɶ�:',datestr(program_start_time,'yyyy-mm-dd HH:MM:SS')])
    disp('--')
    %----------------------------------------------------------------------
    %--
    disp('Ū��R2MS_Lite_v297csv�ɮ�...')
    %--
    f1=fopen(Input_R2MS_Lite_v297csv_filename,'rt');
    if f1<0
        disp(['�}���ɮץ���!return!�ɮצW��:',Input_R2MS_Lite_v297csv_filename,'.'])
        return
    end
    % Ū��
    temp_R2MS_Lite_v297csv_char_data=fread(f1,'*char')';
    % ����
    fclose(f1);
    %--
    disp('Ū��R2MS_Lite_v297csv�ɮ�...����!')
    %--
    % �ˬd�ɮ׮榡����
    if strcmp(temp_R2MS_Lite_v297csv_char_data(1:38),'Time[ms](R2MS_Lite_v297csv_v20240403a)')==1
        disp('�o�O�uv297csv�v�ɮ�!')
    else
        disp('���~!�o���O�uv297csv�v�ɮ�!return!')
        return
    end
    %--
    % ��z���
    temp_data_v297csv_data_cell= strsplit(temp_R2MS_Lite_v297csv_char_data,{',','\n'});
    if isempty(temp_data_v297csv_data_cell{end})
        temp_data_v297csv_data_cell=temp_data_v297csv_data_cell(1:end-1);
    end   
    temp_data_v297csv_data_cell=reshape(temp_data_v297csv_data_cell,131,[])';
    %--
    % �ǳơuR2MS_Lite_v297Ecsv�v���Y�C
    R2MS_Lite_v297Ecsv_Header={['Mode_Index(R2MS_Lite_v297Ecsv_',Version_str,')'],'Tx_Voltage[V]','Rx_Current[A]','Tx_Stutas','Electrode_Status(v/+/-)',...
    'CH01_Voltage[V]','CH01_Current[A]','CH02_Voltage[V]','CH02_Current[A]','CH03_Voltage[V]','CH03_Current[A]',...
	'CH04_Voltage[V]','CH04_Current[A]','CH05_Voltage[V]','CH05_Current[A]','CH06_Voltage[V]','CH06_Current[A]',...
    'CH07_Voltage[V]','CH07_Current[A]','CH08_Voltage[V]','CH08_Current[A]','CH09_Voltage[V]','CH09_Current[A]',...
    'CH10_Voltage[V]','CH10_Current[A]','CH11_Voltage[V]','CH11_Current[A]','CH12_Voltage[V]','CH12_Current[A]',...
    'CH13_Voltage[V]','CH13_Current[A]','CH14_Voltage[V]','CH14_Current[A]','CH15_Voltage[V]','CH15_Current[A]',...
    'CH16_Voltage[V]','CH16_Current[A]','CH17_Voltage[V]','CH17_Current[A]','CH18_Voltage[V]','CH18_Current[A]',...
    'CH19_Voltage[V]','CH19_Current[A]','CH20_Voltage[V]','CH20_Current[A]','CH21_Voltage[V]','CH21_Current[A]',...
    'CH22_Voltage[V]','CH22_Current[A]','CH23_Voltage[V]','CH23_Current[A]','CH24_Voltage[V]','CH24_Current[A]',...
    'CH25_Voltage[V]','CH25_Current[A]','CH26_Voltage[V]','CH26_Current[A]','CH27_Voltage[V]','CH27_Current[A]',...
    'CH28_Voltage[V]','CH28_Current[A]','CH29_Voltage[V]','CH29_Current[A]','CH30_Voltage[V]','CH30_Current[A]',...
    'CH31_Voltage[V]','CH31_Current[A]','CH32_Voltage[V]','CH32_Current[A]','CH33_Voltage[V]','CH33_Current[A]',...
    'CH34_Voltage[V]','CH34_Current[A]','CH35_Voltage[V]','CH35_Current[A]','CH36_Voltage[V]','CH36_Current[A]',...
    'CH37_Voltage[V]','CH37_Current[A]','CH38_Voltage[V]','CH38_Current[A]','CH39_Voltage[V]','CH39_Current[A]',...
    'CH40_Voltage[V]','CH40_Current[A]','CH41_Voltage[V]','CH41_Current[A]','CH42_Voltage[V]','CH42_Current[A]',...
    'CH43_Voltage[V]','CH43_Current[A]','CH44_Voltage[V]','CH44_Current[A]','CH45_Voltage[V]','CH45_Current[A]',...
    'CH46_Voltage[V]','CH46_Current[A]','CH47_Voltage[V]','CH47_Current[A]','CH48_Voltage[V]','CH48_Current[A]',...
    'CH49_Voltage[V]','CH49_Current[A]','CH50_Voltage[V]','CH50_Current[A]','CH51_Voltage[V]','CH51_Current[A]',...
    'CH52_Voltage[V]','CH52_Current[A]','CH53_Voltage[V]','CH53_Current[A]','CH54_Voltage[V]','CH54_Current[A]',...
    'CH55_Voltage[V]','CH55_Current[A]','CH56_Voltage[V]','CH56_Current[A]','CH57_Voltage[V]','CH57_Current[A]',...
    'CH58_Voltage[V]','CH58_Current[A]','CH59_Voltage[V]','CH59_Current[A]','CH60_Voltage[V]','CH60_Current[A]',...
    'CH61_Voltage[V]','CH61_Current[A]','CH62_Voltage[V]','CH62_Current[A]','CH63_Voltage[V]','CH63_Current[A]',...
    'CH64_Voltage[V]','CH64_Current[A]',...
	};
    %--
    [temp_m,temp_n]=size(temp_data_v297csv_data_cell);
    for i=1:temp_m
        if i==1
            for j=1:length(R2MS_Lite_v297Ecsv_Header)
                R2MS_Lite_v297Ecsv_Data{i,j}=R2MS_Lite_v297Ecsv_Header{j};
            end
        else
            R2MS_Lite_v297Ecsv_Data{i,1}=temp_data_v297csv_data_cell{i,2};
            R2MS_Lite_v297Ecsv_Data{i,2}='0';
            R2MS_Lite_v297Ecsv_Data{i,3}='0';
            R2MS_Lite_v297Ecsv_Data{i,4}='2';            
            for j=3:temp_n
                R2MS_Lite_v297Ecsv_Data{i,j+2}=temp_data_v297csv_data_cell{i,j};
            end
        end
    end
    disp('--')
    disp('��XR2MS_Lite_v297Ecsv�ɮ�...�}�l')
    %----------------------------------------------------------------------
    % �g�JR2MS_Lite_v297Ecsv�ɮ�
    %--
    % �Y���s�b�h�إ߸�Ƨ�
    if ~(exist(Output_R2MS_Lite_v297Ecsv_folder,'dir')==7)
        mkdir(Output_R2MS_Lite_v297Ecsv_folder)
    end
    %--    
    % �}��
    f1=fopen([Output_R2MS_Lite_v297Ecsv_folder,'\',Output_R2MS_Lite_v297Ecsv_filename,'.v297E.csv'],'wt');
    if f1<0
        disp(['�}���ɮץ���!return!�ɮצW��:',[Output_R2MS_Lite_v297Ecsv_folder,'\',Output_R2MS_Lite_v297Ecsv_filename,'.v297E.csv'],'.'])
        return
    end
    % �g�ɮ�
    for i=1:length(R2MS_Lite_v297Ecsv_Data(:,1))
        fprintf(f1,'%s,',R2MS_Lite_v297Ecsv_Data{i,1:end-1});
        fprintf(f1,'%s\n',R2MS_Lite_v297Ecsv_Data{i,end});
    end
    % ����
    fclose(f1);
    %----------------------------------------------------------------------
    disp('��XR2MS_Lite_v297Ecsv�ɮ�...����!')
    disp('--')
    %----------------------------------------------------------------------
    disp('�{���B�槹��!')
    disp(['�{���B�槹��...�ɶ�:',datestr(now,'yyyy-mm-dd HH:MM:SS')])
    disp('==================================================')


    