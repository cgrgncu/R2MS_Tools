%**************************************************************************
%   Name: Main.m v20240810a
%   Copyright:  
%   Author: HsiupoYeh 
%   Version: v20240810a
%   Description: R2MS_Lite_v297_Archive���I�s�d�ҡC
%   �ݨD: 
%   Main.m                           
%   R2MS_Lite_v297_Archive.m         
%   R2MS_Lite_v297rawcsv_to_v297csv.m
%   json_decode.m                    
%   json_decode.mexw64               
%   json_encode.m                    
%   json_encode.mexw64               
%   yeh_MD5_checksum.m               
%   yeh_ini2struct_ansi.m    
%**************************************************************************
clear;clc;close all
% �D�{���Ѽ�INI�ɮצ�m
main_ini_full_file_name='Input_ini\R2MS_Lite_v297_Archive.ini';
% ���XINI�Ѽ�
IniFile=yeh_ini2struct_ansi(main_ini_full_file_name);
% �I�s
R2MS_Lite_v297_Archive(...
    IniFile.Struct.R2MS_Lite_v297_Archive.Target_Archive_Year,...
    IniFile.Struct.R2MS_Lite_v297_Archive.Target_Archive_Month,...
    IniFile.Struct.R2MS_Lite_v297_Archive.v297_DATA_Folder,...
    IniFile.Struct.R2MS_Lite_v297_Archive.Project_Folder_Name,...
    IniFile.Struct.R2MS_Lite_v297_Archive.Project_Profile_Name,...
    IniFile.Struct.R2MS_Lite_v297_Archive.SwitchArray_SN);
